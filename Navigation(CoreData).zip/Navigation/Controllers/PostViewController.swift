//
//  PostViewController.swift
//  Navigation
//
//  Created by Suharik on 11.03.2022.
//

import UIKit
import SnapKit

enum AppConfiguration: String {
    case one =  "https://swapi.dev/api/films/1"
    case two = "https://swapi.dev/api/people/2"
    case three = "https://swapi.dev/api/vehicles/3"
}


class PostViewController: UIViewController {
    struct NetworkService {
        static func request(for configuration: AppConfiguration) {
            if let url = URL(string: configuration.rawValue) {
                let task = URLSession.shared.dataTask(with: url) { data, response, error in
                    if error == nil, let data = data, let response = response as? HTTPURLResponse {
                        print("\nDATA: \(String(decoding: data, as: UTF8.self))")
                        print("\nRESPONSE STATUS: \(response.statusCode)")
                        print("\nRESPONSE HEADER: \(response.allHeaderFields)")
                    } else {
                        print("\nLOCAL ERROR: \(error?.localizedDescription ?? "Unknown error")")
                        print("\nDEBUG ERROR: \(error.debugDescription)")
                    }
                }
                task.resume()
            }
        }
    }
    public struct Info {
        var userId: Int = 0
        var id: Int = 0
        var title: String = ""
        var completed: Bool = false
    }
    
    public struct Planet: Codable {
        var name: String
        var rotationPeriod: String
        var orbitalPeriod: String
        var diameter: String
        var climate: String
        var gravity: String
        var terrain: String
        var surfaceWater: String
        var population: String
        var residents: [String]
        var films: [String]
        var created: String
        var edited: String
        var url: String
        
        enum CodingKeys: String, CodingKey {
            case name
            case rotationPeriod = "rotation_period"
            case orbitalPeriod = "orbital_period"
            case diameter
            case climate
            case gravity
            case terrain
            case surfaceWater = "surface_water"
            case population
            case residents
            case films
            case created
            case edited
            case url
        }
    }

    final class InfoNetworkManager {
        static let shared = InfoNetworkManager()
        private let stringURL = "https://jsonplaceholder.typicode.com/todos/20"
        public var info = Info()
        public func urlSession() {
            if let url = URL(string: stringURL) {
                let task = URLSession.shared.dataTask(with: url) {data, response, error in
                    if error != nil {
                        print("ERROR: \(error!.localizedDescription)")
                    } else {
                        do {
                            let json = try! JSONSerialization.jsonObject(with: data!, options: .allowFragments) as? [String:Any]
                            self.info.title = json!["title"] as? String ?? "unknown"
                            print("DONE: \(self.info.title)")
                        }
                    }
                }
                task.resume()
            }
        }
    }
    
    final class PlanetsNetworkManager {
        static let shared = PlanetsNetworkManager()
        private var isFetched = false
        private let stringURL = "https://swapi.dev/api/planets/1"
        public var planet: Planet?
        func fetchPlanetsData() {
            guard isFetched == false else { return }
            if let url = URL(string: stringURL){
                let task = URLSession.shared.dataTask(with: url) { data, response, error in
                    if let unwrappedData = data {
                        do {
                            self.planet = try JSONDecoder().decode(Planet.self, from: unwrappedData)
                            self.isFetched = true
                        }
                        catch let error {
                            print("PLANET ERROR: \(error.localizedDescription)")
                        }
                    }
                }
                task.resume()
            }
        }
    }
    
    private lazy var urlTextView: UITextView = {
        let textView = UITextView()
        textView.layer.cornerRadius = 12
        textView.clipsToBounds = true
        textView.layer.borderWidth = 1
        textView.layer.borderColor = UIColor.black.cgColor
        textView.backgroundColor = .white
        textView.font = UIFont.systemFont(ofSize: 15, weight: .regular)
        return textView
    }()
    
    private lazy var planetTextView: UITextView = {
        let textView = UITextView()
        textView.layer.cornerRadius = 12
        textView.clipsToBounds = true
        textView.layer.borderWidth = 1
        textView.layer.borderColor = UIColor.black.cgColor
        textView.backgroundColor = .white
        textView.font = UIFont.systemFont(ofSize: 15, weight: .regular)
        return textView
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.navigationBar.prefersLargeTitles = true
        self.view.backgroundColor = .white
        let button = UIBarButtonItem(barButtonSystemItem: .compose, target: self, action: #selector(openInfo))
        navigationItem.rightBarButtonItem = button
        self.view.addSubview(urlTextView)
        self.view.addSubview(planetTextView)
        urlTextView.text = "Title: \(InfoNetworkManager.shared.info.title)"
        planetTextView.text = "Orbital period of Tatooine is \(PlanetsNetworkManager.shared.planet!.orbitalPeriod)"
        setupFeedLayout()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.tabBarController?.tabBar.isHidden = true
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        self.tabBarController?.tabBar.isHidden = false
    }
    
    @objc func openInfo(){
        let rootVC = InfoViewController()
        let navVC = UINavigationController(rootViewController: rootVC)
        present(navVC, animated: true)
    }
    
    
    private func setupFeedLayout() {
        urlTextView.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.top.equalTo(view.safeAreaLayoutGuide.snp.top)
            make.trailing.equalToSuperview().offset(-16)
            make.leading.equalToSuperview().offset(16)
            make.height.equalTo(200)
            
        }
        
        planetTextView.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.top.equalTo(urlTextView.snp.bottom).offset(16)
            make.trailing.equalToSuperview().offset(-16)
            make.leading.equalToSuperview().offset(16)
            make.height.equalTo(200)
        }
    }
    
    class InfoViewController: UIViewController {
        override func viewDidLoad() {
            super.viewDidLoad()
            view.backgroundColor = .white
            title = "Информация"
            view.addSubview(buttonAlert)
            setupButton()
            buttonAlert.tapAction = { [weak self] in
                guard let self = self else { return }
                self.showAlertButtonTapped()
            }
        }
        @IBAction func showAlertButtonTapped() {
            let alert = UIAlertController(title: "ВнИмАнИе", message: "Шо то идет не так...", preferredStyle: UIAlertController.Style.actionSheet)
            alert.addAction(UIAlertAction(title: "Понято", style: UIAlertAction.Style.default, handler: nil))
            alert.addAction(UIAlertAction(title: "Непонято", style: UIAlertAction.Style.destructive, handler: nil))
            alert.addAction(UIAlertAction(title: "Выйти", style: UIAlertAction.Style.cancel, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
        
        private lazy var buttonAlert: CustomButton = {
            let button = CustomButton (
                title: "Открыть предупреждение",
                titleColor: .black,
                backColor: .systemIndigo,
                backImage: UIImage()
            )
            return button
        }()
        
        func setupButton(){
            buttonAlert.snp.makeConstraints { make in
                make.centerX.equalToSuperview()
                make.bottom.equalTo(view.safeAreaLayoutGuide.snp.bottom)
                make.leading.trailing.equalToSuperview().inset(16)
                make.height.equalTo(50)
            }
        }
    }
}


