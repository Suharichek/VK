//
//  PostTableViewCell.swift
//  Navigation
//
//  Created by Suharik on 03.04.2022.
//

import UIKit
import SnapKit

class PostTableViewCell: UITableViewCell {
    static let identifire = "PostTableViewCell"
    
    private let contentMyView: UIView = {
        var view = UIView()
        view.backgroundColor = .white
        return view
    }()
    
    private let postImage: UIImageView = {
        var postImageView = UIImageView()
        postImageView.contentMode = .scaleAspectFit
        postImageView.backgroundColor = .black
        return postImageView
    }()
    
    private lazy var postAuthor: UILabel = {
        let postAuthor = UILabel()
        postAuthor.numberOfLines = 2
        postAuthor.font = UIFont.systemFont(ofSize: 20, weight: .light)
        postAuthor.textColor = .gray
        return postAuthor
    }()
    
    let postID: UILabel = {
        var postAuthor = UILabel()
        postAuthor.lineBreakMode = .byWordWrapping
        postAuthor.numberOfLines = 0
        postAuthor.font = UIFont.boldSystemFont(ofSize: 20)
        postAuthor.textColor = .black
        return postAuthor
    }()
    
    private let postDescription: UILabel = {
        var postDescription = UILabel()
        postDescription.lineBreakMode = .byWordWrapping
        postDescription.numberOfLines = 0
        postDescription.font = .systemFont(ofSize: 14)
        postDescription.textColor = .systemGray
        return postDescription
    }()
    
    private let postLikes: UILabel = {
        var postLikes = UILabel()
        postLikes.font = .systemFont(ofSize: 16)
        postLikes.textColor = .black
        return postLikes
    }()
    
    private let postViews: UILabel = {
        var postViews = UILabel()
        postViews.font = .systemFont(ofSize: 16)
        postViews.textColor = .black
        return postViews
    }()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        customizeCell()
        setupContent()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    weak var viewModel: PostTableViewCellViewModel? {
        willSet(viewModel) {
            guard let viewModel = viewModel else { return }
            postAuthor.text = "Автор: \(viewModel.author)"
            postID.text = viewModel.title
            postDescription.text = viewModel.description
            postImage.image = viewModel.image
            postLikes.text = "Лайки: \(viewModel.likes)"
            postViews.text = "Просмотры: \(viewModel.views)"
        }
    }
    
    public func configureOfCell (_ post: Post) {
        self.postID.text = post.title
        self.postAuthor.text = "Автор: \(post.author)"
        self.postImage.image = post.image
        self.postDescription.text = post.description
        self.postLikes.text = "Лайки: \(post.likes)"
        self.postViews.text = "Просмотры: \(post.views)"
    }
    
    private func customizeCell() {
        contentView.backgroundColor = .systemGray6
    }
    
    private func setupContent(){
        contentView.addSubview(contentMyView)
        contentView.addSubview(postAuthor)
        contentView.addSubview(postID)
        contentView.addSubview(postImage)
        contentView.addSubview(postDescription)
        contentView.addSubview(postLikes)
        contentView.addSubview(postViews)
        
        contentMyView.snp.makeConstraints { make in
            make.leading.top.trailing.bottom.equalToSuperview()
        }
        
        postID.snp.makeConstraints { make in
            make.top.equalTo(contentMyView.snp.top).inset(8)
            make.leading.equalTo(contentMyView.snp.leading).inset(16)
        }
        
        postAuthor.snp.makeConstraints { make in
            make.top.equalTo(contentMyView.snp.top).offset(8)
            make.trailing.equalTo(contentMyView.snp.trailing).inset(16)
        }
        
        postImage.snp.makeConstraints { make in
            make.top.equalTo(postAuthor.snp.bottom).offset(8)
            make.leading.equalTo(contentMyView.snp.leading)
            make.width.height.equalTo(contentMyView.snp.width)
        }
        
        postDescription.snp.makeConstraints { make in
            make.top.equalTo(postImage.snp.bottom).offset(16)
            make.leading.equalTo(contentMyView.snp.leading).inset(16)
            make.trailing.equalTo(contentMyView.snp.trailing).inset(16)
        }
        
        postLikes.snp.makeConstraints { make in
            make.top.equalTo(postDescription.snp.bottom).offset(3)
            make.leading.equalTo(contentMyView.snp.leading).inset(16)
            make.bottom.equalTo(contentMyView.snp.bottom).inset(3)
        }
        
        postViews.snp.makeConstraints { make in
            make.top.equalTo(postDescription.snp.bottom).offset(3)
            make.trailing.equalTo(contentMyView).inset(16)
            make.bottom.equalTo(contentMyView.snp.bottom).inset(3)
        }
    }
}
