//
//  FeedViewController.swift
//  Navigation
//
//  Created by Suharik on 11.03.2022.
//

import UIKit
import SnapKit

class FeedViewController: UIViewController {
    
    //MARK: Properties
    
    private var model = Model()
    private lazy var postButton: CustomButton = {
        let button = CustomButton (
            title: "postButtonTitle".localized,
            titleColor: .textColor,
            backColor: .buttonColor,
            backImage: UIImage()
        )
        button.clipsToBounds = false
        button.layer.shadowOffset = CGSize(width: 0.0, height: 3.0)
        button.layer.shadowRadius = 5.0
        button.layer.shadowColor = UIColor.black.cgColor
        button.layer.shadowOpacity = 0.8
        return button
    }()
    
    private lazy var passTextField: UITextField = {
        let textField = UITextField()
        textField.layer.cornerRadius = 12
        textField.textColor = .textColor
        textField.clipsToBounds = true
        textField.layer.borderWidth = 1
        textField.layer.borderColor = UIColor.black.cgColor
        textField.backgroundColor = .labelBackColor
        textField.placeholder = "passwordTextField".localized
        textField.font = UIFont.systemFont(ofSize: 15, weight: .regular)
        textField.leftViewMode = .always
        textField.leftView = UIView(frame: CGRect(x: 0, y: 0, width: 10, height: textField.frame.height))
        textField.clearButtonMode = UITextField.ViewMode.whileEditing
        return textField
    }()
    
    private lazy var checkButton: CustomButton = {
        let button = CustomButton (
            title: "checkButton".localized,
            titleColor: .textColor,
            backColor: .buttonColor,
            backImage: UIImage()
        )
        return button
    }()
    
    private lazy var someLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 17, weight: .regular)
        label.textAlignment = .center
        return label
    }()
    
    //MARK: Main Functions
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.navigationBar.prefersLargeTitles = true
        self.navigationItem.title = "feedTitle".localized
        view.backgroundColor = .backgroundColor
        
        checkButton.setTitleColor(.textColor, for: .normal)
        postButton.setTitleColor(.textColor, for: .normal)
        setupFeedLayout()
        
        postButton.tapAction = { [weak self] in
            guard let self = self else { return }
            self.showNewPostVC()
        }
        
        checkButton.tapAction = { [weak self] in
            guard let self = self else { return }
            self.someButtonAction()
        }
        
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(codeRed),
            name: NSNotification.Name.codeRed,
            object: nil
        )
        
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(codeGreen),
            name: NSNotification.Name.codeGreen,
            object: nil
        )
    }
    
    private func setupFeedLayout() {
        self.view.addSubview(postButton)
        self.view.addSubview(someLabel)
        self.view.addSubview(passTextField)
        self.view.addSubview(checkButton)
        
        someLabel.snp.makeConstraints { make in
            make.center.equalToSuperview()
            make.width.equalTo(200)
            make.height.equalTo(40)
        }
        
        passTextField.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.top.equalTo(someLabel.snp.bottom).offset(16)
            make.width.equalTo(200)
            make.height.equalTo(40)
        }
        
        checkButton.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.top.equalTo(passTextField.snp.bottom).offset(16)
            make.width.equalTo(150)
            make.height.equalTo(50)
        }
        
        postButton.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.bottom.equalTo(view.safeAreaLayoutGuide.snp.bottom).offset(-16)
            make.width.equalTo(150)
            make.height.equalTo(50)
        }
    }
    
    //MARK: Added Functions
    
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.navigationBar.isHidden = false
        self.tabBarController?.tabBar.isHidden = false
    }
    
    @objc func codeRed() {
        someLabel.text = "codeRed".localized
        someLabel.textColor = .red
    }
    
    @objc func codeGreen() {
        someLabel.text = "codeGreen".localized
        someLabel.textColor = .green
    }
    
    private func someButtonAction() {
        model.check(word: passTextField.text!)
    }
    
    private func showNewPostVC() {
        let postVC = PostViewController()
        postVC.title = "newPostTitle".localized
        postVC.view.backgroundColor = .backgroundColor
        self.navigationController?.pushViewController(postVC, animated: true)
    }
    
    func userNotificationCenter(_ center: UNUserNotificationCenter, didReceive response: UNNotificationResponse, withCompletionHandler completionHandler: @escaping () -> Void) {
        switch response.actionIdentifier {
        case UNNotificationDefaultActionIdentifier:
            print("Ни одна из кнопок не нажата")
        case "Показать":
            print("Была нажата кнопка Показать")
        case "Спрятать":
            print("Была нажата кнопка Спрятать")
        default:
            print("Была нажата кнопка")
        }
        completionHandler()
    }
}
